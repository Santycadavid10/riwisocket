
const direccion = "http://192.168.1.32:3002/"


function iniciar(){
    
var bd // creo variable para guardar base de datos
var elementocaja
var coins = []
var persons = []


var inputBusqueda = document.getElementById('formulario-busqueda');
const baja = document.getElementById("bajoo")
const padre = document.getElementById("padre");
const hijo = document.getElementById("registrar");


function iniciarbasededatos() { //creo funcion para cuando inicie base datos // guardo boton en variable
    elementocaja = document.querySelector('.cajaa') // creo addlistener para cuando de click almacenes
    var solicitud = indexedDB.open('DatosEstudiante')
    solicitud.addEventListener('error', MostrarError)
    solicitud.addEventListener('upgradeneeded', CrearAlmacen)
    solicitud.addEventListener('success', Comenzar)     
}

function MostrarError(evento) {
    alert('tenemos un error:' + evento.code + '/' + evento.message) // mensaje si sucede un error
}

function CrearAlmacen(evento) {
    // funcion para inicialmente crear almacen
    var basedatos = evento.target.result
    var almacen = basedatos.createObjectStore('contactos', { keyPath: 'id' }) // creo almacen
    almacen.createIndex('Buscarriwi', 'riwicoins', { unique: false, order: 'desc' });


}


function Comenzar(evento) {
bd = evento.target.result
mostrar()
buscarestudiante();
}


function mostrar() {
    elementocaja = document.querySelector('.cajaa') 
    window.scrollTo({
        top: 5,
        behavior: 'smooth'
    });

    transaccion = bd.transaction(['contactos']) // utilizo el metodo transaccion  para indicar que se va hacer una transacion de informacion de  la base de datos  .transacccion(-[almmacen donde se hara la transacion], "readonly " o vacio por que es el valor por defecto )
    almacen = transaccion.objectStore('contactos') // abro almacen
    var index = almacen.index('Buscarriwi');
    var puntero = index.openCursor(null, 'prev'); // abrir cursor
    puntero.addEventListener('success', MostrarContactos)
    function MostrarContactos(evento) {
        var puntero = evento.target.result
            if (puntero) {
                persons.push(puntero.value)
                        const Bontonpersona = document.createElement("button");// creo un elemento boton con ell cual iniciar un proceso
                        const contname = document.createElement("span");  
                        const textocontname = document.createTextNode
                        (puntero.value.nombre + "-----" + "CLan:  " +puntero.value.clan);
                        contname.appendChild(textocontname)
                        contname.classList.add("nombre");
                        const contpuntos = document.createElement("span");  
                        const textocontpuntos = document.createTextNode
                        (puntero.value.riwicoins +  "  " +  " riwicoins");
                        contpuntos.appendChild(textocontpuntos) // string que se desea mostrar
                        contpuntos.classList.add("puntos");
                        Bontonpersona.appendChild(contname);
                        Bontonpersona.appendChild(contpuntos);
                        Bontonpersona.setAttribute("id", puntero.value.id);
                        Bontonpersona.setAttribute("name", puntero.value.nombre);
                        Bontonpersona.setAttribute("clan", puntero.value.clan);
                        Bontonpersona.setAttribute("celular", puntero.value.celular);
                        Bontonpersona.setAttribute("riwicoins", puntero.value.riwicoins);
                        Bontonpersona.addEventListener("click", function (){
                        const nombreBoton = this.getAttribute("name");
                        const clanBoton = this.getAttribute("clan");
                        const idBoton = this.getAttribute("id");
                        const celularBoton = this.getAttribute("celular");
                        const riwiBoton = this.getAttribute("riwicoins");
                        seleccionarestudiante(nombreBoton, clanBoton, idBoton, celularBoton, riwiBoton)
                        
                        });
            
                elementocaja.appendChild(Bontonpersona);
                puntero.continue();
                
                
            }
    }
    console.log(persons)
    const socket = io();

    // Enviar datos al servidor
    socket.emit('datosDesdeCliente', { persons });

}
  
function buscarestudiante (){
    inputBusqueda.addEventListener('input', function () {
        var valorBusqueda = inputBusqueda.value;

        while (elementocaja.firstChild) {
            elementocaja.removeChild(elementocaja.firstChild);
        }

        var transaccion = bd.transaction(['contactos']) // utilizo el metodo transaccion  para indicar que se va hacer una transacion de informacion de  la base de datos  .transacccion(-[almmacen donde se hara la transacion], "readonly " o vacio por que es el valor por defecto )
        var almacen = transaccion.objectStore('contactos') // abro almacen
        var puntero = almacen.openCursor() // abrir cursor // creo ad listener que se active al evento suceso
        puntero.addEventListener('success', Mostrarbusquedaresultados) 
        
        function Mostrarbusquedaresultados(evento) {
            var puntero = evento.target.result
            if (puntero) {
                valorBusqueda = valorBusqueda.toString();
                idcomparado = puntero.value.id;
                nombrecomparado = puntero.value.nombre;
                idcomparado = idcomparado.toString();
                if(idcomparado.includes(valorBusqueda) || nombrecomparado.includes(valorBusqueda)){

                    const Bontonpersona = document.createElement("button");// creo un elemento boton con ell cual iniciar un proceso
                    const contname = document.createElement("span");  
                    const textocontname = document.createTextNode
                    (puntero.value.nombre);
                    contname.appendChild(textocontname)
                    contname.classList.add("nombre");
                    const contpuntos = document.createElement("span");  
                    const textocontpuntos = document.createTextNode
                    (puntero.value.riwicoins +  "  " +  " riwicoins");
                    contpuntos.appendChild(textocontpuntos) // string que se desea mostrar
                    contpuntos.classList.add("puntos");
                    Bontonpersona.appendChild(contname);
                    Bontonpersona.appendChild(contpuntos);
                    Bontonpersona.setAttribute("id", puntero.value.id);
                    Bontonpersona.setAttribute("name", puntero.value.nombre);
                    Bontonpersona.setAttribute("clan", puntero.value.clan);
                    Bontonpersona.setAttribute("celular", puntero.value.celular);
                    Bontonpersona.setAttribute("riwicoins", puntero.value.riwicoins);
                    Bontonpersona.addEventListener("click", function (){
                        const nombreBoton = this.getAttribute("name");
                        const clanBoton = this.getAttribute("clan");
                        const idBoton = this.getAttribute("id");
                        const celularBoton = this.getAttribute("celular");
                        const riwiBoton = this.getAttribute("riwicoins");
                        seleccionarestudiante(nombreBoton, clanBoton, idBoton, celularBoton, riwiBoton)
                    });
                    elementocaja.appendChild(Bontonpersona);
                }
                puntero.continue();
            }
        }   
    });
}

function seleccionarestudiante(nombreBoton, clanBoton, idBoton, celularBoton, riwiBoton){
    
        window.scrollTo({
        top: 5,
        behavior: 'smooth'
    });

    while (elementocaja.firstChild) {
        elementocaja.removeChild(elementocaja.firstChild);
    }

    var formularioElement = document.createElement("form");
    var divTitulo = document.createElement("div");
    divTitulo.className = "titulo";
    var h1Element = document.createElement("h1");
    h1Element.textContent = "Editar Estudiante";
    divTitulo.appendChild(h1Element);
    // Agregar el div al formulario
    formularioElement.appendChild(divTitulo);

    // Crear las etiquetas con los inputs y selects
    var etiquetas = [
        { tipo: "number", id: "riwi", placeholder: "Riwi coins =  " + riwiBoton + " poner el +/- y el numero de coins a agregar" },
        { tipo: "text", id: "cliente", placeholder: "Nombre", value: nombreBoton },
        { tipo: "select", id: "clan",  opciones: [ "tesla", "linux", "python", "js"], value: clanBoton},
        { tipo: "number", id: "id", placeholder: "Cedula", value: idBoton },
        { tipo: "number", id: "celular", placeholder: "Celular", value: celularBoton}
    ];

    etiquetas.forEach(function (etiqueta) {
        var labelElement = document.createElement("label");

        if (etiqueta.tipo === "select") {
            var selectElement = document.createElement("select");
            selectElement.id = etiqueta.id;
            etiqueta.opciones.forEach(function (opcion) {
                var optionElement = document.createElement("option");
                optionElement.textContent = opcion;
                selectElement.appendChild(optionElement);
                selectElement.value = etiqueta.value;
            });
        labelElement.appendChild(selectElement);
        } 
        else {
            var inputElement = document.createElement("input");
            inputElement.id = etiqueta.id;
            inputElement.type = etiqueta.tipo;
            inputElement.placeholder = etiqueta.placeholder;
            inputElement.value = etiqueta.value;
            labelElement.appendChild(inputElement);
        }
        formularioElement.appendChild(labelElement);
    });

// Crear el botón
    var botonEditar = document.createElement("button");
    botonEditar.className = "red";
    botonEditar.type = "button";
    botonEditar.id = "editar";
    botonEditar.textContent = "Editar";
    botonEditar.addEventListener("click", function (){

        var N = document.querySelector('#cliente').value
        var I = document.querySelector('#id').value
        var C = document.querySelector('#clan').value
        var CE = document.querySelector('#celular').value
        var  tartaria = document.querySelector('#riwi').value;
        if(tartaria == ""){
            tartaria = 0;
        }
        var R =  parseInt(tartaria, 10) + parseInt(riwiBoton, 10);

        var transaccion = bd.transaction(['contactos'], 'readwrite')
        var almacen = transaccion.objectStore('contactos')
        
        var estudiante = {
            nombre: N,
            id: I,
            clan: C,
            celular: CE,
            riwicoins: R,
        }

        almacen.put(estudiante);
        while (elementocaja.firstChild) {
            elementocaja.removeChild(elementocaja.firstChild);  
        }
        const socket = io.connect('direccion');
        socket.emit('enviarDatos', estudiante);

        iniciarbasededatos();
    });

    var botonEliminar = document.createElement("button");
    botonEliminar.className = "red";
    botonEliminar.type = "button";
    botonEliminar.id = "eliminar";
    botonEliminar.textContent = "Eliminar";
    botonEliminar.addEventListener("click", function (){
        console.log("santy");
    });
    // Agregar el botón al formulario
    formularioElement.appendChild(botonEditar);
    formularioElement.appendChild(botonEliminar);
    // Agregar el formulario al contenedor con la clase "cajaa"
    elementocaja.appendChild(formularioElement);
}

var divPadre = document.createElement('div');
divPadre.setAttribute('id', 'padre');

// Crear el elemento button
var botonRegistrar = document.createElement('button');
botonRegistrar.setAttribute('id', 'registrar');
botonRegistrar.setAttribute('class', 'red');
botonRegistrar.textContent = 'ingresar';

// Agregar el botón al div
divPadre.appendChild(botonRegistrar);

// Agregar el div al body (o a cualquier otro elemento que desees)
document.body.appendChild(divPadre);

// Agregar un evento de clic al botón
botonRegistrar.addEventListener('click', registro);


function registro(){
    
    const registro =  `
                        <form>
                        <div class="titulo">
                        <h1>Registro Riwi</h1>
                        </div>

                        <label>
                        <input id="name" type="text" placeholder="Nombre" />
                        </label>
                        <label>
                        <select  id="clan">
                        <option value="Clan" disabled selected >Escoge un clan</option>
                        <option value="tesla">tesla</option>
                        <option value="linux">linux</option>
                        <option value="python">python</option>
                        <option value="js">js</option>
                        </select>
                        </label>
                        <label>
                        <input id="id" type="number" placeholder="Cedula" />
                        </label>
                        <label>
                        <input id="celular" type="number" placeholder="celular" />
                        </label>
                        
                        <button class="red" type="button" id="inicio">Registar</button>
                        <button class="red" type="button" id="participantes">Ver participantes</button>
                        </form>
                        `
    baja.innerHTML = registro
    var BtnGuardar = document.querySelector('#inicio')
    BtnGuardar.addEventListener('click', AlmacenarContacto)
    var verparticipantes = document.querySelector('#participantes')
    verparticipantes.addEventListener('click', recarga)
 }



 function AlmacenarContacto() {
    var N = document.querySelector('#name').value
    var I = document.querySelector('#id').value
    var C = document.querySelector('#clan').value
    var CE = document.querySelector('#celular').value

    var transaccion = bd.transaction(['contactos'], 'readwrite')
    var almacen = transaccion.objectStore('contactos')
    
    almacen.add({
        nombre: N,
        id: I,
        clan: C,
        celular: CE,
        riwicoins: 0,
    })

    document.querySelector('#name').value = ''
    document.querySelector('#id').value = ''
    document.querySelector('#clan').value = 'Clan'
    document.querySelector('#celular').value = ''
}



function recarga() {

    const gente  = `
    <div class="cajaa" >
          
    </div>  
    <div class="continput">
        <input type="text"  id="formulario-busqueda">
        <img src="./imag/Vei.gif" alt="" id="imagpublicidad">
        
    </div > 
    <div id="padre">
    <button id="registrar" class="red" onclick="registro()">
      ingresar
    </button>
    </div>
    </div>
                    `
    
    baja.innerHTML = gente
    mostrar();
}
     iniciarbasededatos();
}




const socket = io();

socket.on('connect', () => {

    socket.on('clientIpAddress', (clientIp) => {
        if(clientIp == "::ffff:192.168.1.32"){
            console.log("aqui estamos")
            iniciar()
        }
        else{
            console.log("miscompas")
        };
      });

  
});




 