const path = require('path');
const express = require('express');
const app = express();
const SocketIO = require('socket.io')


app.set('port', process.env.PORT || 3001)


//static files
app.use(express.static(path.join(__dirname, 'registrar')));

const server = app.listen(app.get('port'), () => {
    console.log('server on port', app.get('port'));
});


//web sockets
const io = SocketIO(server);

io.on("connection", (socket) => {
    console.log("new connection", socket.id)
});