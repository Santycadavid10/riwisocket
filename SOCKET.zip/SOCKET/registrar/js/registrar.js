var bd // creo variable para guardar base de datos
var cajaContactos

function iniciarbasededatos() {
    //creo funcion para cuando inicie base datos
    var BtnGuardar = document.querySelector('#inicio') // guardo boton en variable
    cajaContactos = document.querySelector('#caja')
    BtnGuardar.addEventListener('click', AlmacenarContacto) // creo addlistener para cuando de click almacenes

    var solicitud = indexedDB.open('DatosEstudiante') // creo variable para cuando quiera abrir la base datos
    solicitud.addEventListener('error', MostrarError) //creo evento para error
    solicitud.addEventListener('success', Comenzar) // creo evento para cuando comienze a guardar
    solicitud.addEventListener('upgradeneeded', CrearAlmacen) //creo evento para cuando se intente acceder a una base datos sin existir
}

function MostrarError(evento) {
    alert('tenemos un error:' + evento.code + '/' + evento.message) // mensaje si sucede un error
}

function Comenzar(evento) {
    bd = evento.target.result // Asignar los datos del archivo a la variable bd basedatos
   
}

function CrearAlmacen(evento) {
    // funcion para inicialmente crear almacen
    var basedatos = evento.target.result
    var almacen = basedatos.createObjectStore('contactos', { keyPath: 'id' }) // creo almacen
    almacen.createIndex('Buscarriwi', 'riwicoins', { unique: false, order: 'desc' });


}

window.addEventListener('load', iniciarbasededatos) // inicio funcion iniciarbasededatos al load cargar

//ingreso datos

function AlmacenarContacto() {
    var N = document.querySelector('#nombre').value
    var I = document.querySelector('#id').value
    var C = document.querySelector('#clan').value
    var CE = document.querySelector('#celular').value

    var transaccion = bd.transaction(['contactos'], 'readwrite')
    var almacen = transaccion.objectStore('contactos')
    
    almacen.add({
        nombre: N,
        id: I,
        clan: C,
        celular: CE,
        riwicoins: 0,
    })

    document.querySelector('#nombre').value = ''
    document.querySelector('#id').value = ''
    document.querySelector('#clan').value = 'Clan'
    document.querySelector('#celular').value = ''
}

