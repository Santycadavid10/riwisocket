const path = require('path');
const express = require('express');
const app = express();
const SocketIO = require('socket.io')


app.set('port', process.env.PORT || 3001)


//static files
app.use(express.static(path.join(__dirname, 'mostrar')));

const server = app.listen(app.get('port'), () => {
    console.log('server on port', app.get('port'));
});


//web sockets


const io = SocketIO(server);







  io.on('connection', (socket) => {
    console.log('Cliente conectado');



    socket.on('enviarDatos', (estudiante) => {
      console.log('Datos recibidos del cliente:', estudiante);
      // Aquí puedes hacer lo que necesites con los datos recibidos del cliente
      // Reenviar la información a todos los demás clientes conectados
      socket.broadcast.emit('enviarPersons', estudiante);
  });



    

    // Manejar la desconexión del cliente
    socket.on('disconnect', () => {
        console.log('Cliente desconectado');
    });
});