const path = require('path');
const express = require('express');
const app = express();
const http = require('http'); // Necesario para crear el servidor HTTP
const SocketIO = require('socket.io');
const os = require('os');

const connectedClients = [];
const ipprincipal = "::ffff:192.168.1.29";
var estudiantes = [];

app.set('port', process.env.PORT || 3002);

const interfaces = os.networkInterfaces();
const IPconectada = interfaces.enp1s0[0].address;
console.log("nueva ip" + IPconectada);

const server = http.createServer(app); // Crear el servidor HTTP
server.listen(app.get('port'), () => {
    console.log('server on port', app.get('port'));
});

const io = SocketIO(server); // Crear el servidor de Socket.IO

// Manejo de conexiones de sockets
io.on('connection', (socket) => {
    const clientIp = socket.request.connection.remoteAddress;
    connectedClients.push(clientIp);
    socket.emit('clientIpAddress', clientIp);  

    if (clientIp === ipprincipal) {
        socket.on('datosDesdeCliente', (data) => {
            estudiantes = data.persons;
        });
    } else {
        socket.on("datosDesdeCliente", (data) => {
          estudiantes = data.persons;
        });
        if (connectedClients.includes(ipprincipal)) {
            console.log("no es el principal");
            socket.emit('datosDelservidor', { estudiantes });
        } else {
            console.log("pc principal no conectado");
        }
    }

    // Manejo del evento 'estudiantemodificado'
    socket.on('estudiantemodificado', function(data) {
        var estudiante = data.estudiante;
        console.log("holaaaaaaaaa" + estudiante);
        // Emitir el evento a todos los clientes conectados, no solo al que lo emitió
        io.emit('actualizarestudiante', { estudiante });
    });

    // Manejar la desconexión del cliente
    socket.on('disconnect', () => {
        console.log('Cliente desconectado' + connectedClients);
    });
});

// Archivos estáticos
app.use(express.static(path.join(__dirname, 'mostrar')));
















