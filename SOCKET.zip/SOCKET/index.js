const path = require('path');
const express = require('express');
const app = express();
const SocketIO = require('socket.io')
const os = require('os');
const connectedClients = [];
const ipprincipal = "::ffff:192.168.0.65"
var estudiantes = [];
app.set('port', process.env.PORT || 3002)

const interfaces = os.networkInterfaces();
const IPconectada = interfaces.enp1s0[0].address;
console.log("nueva ip" + IPconectada)
const server = app.listen(app.get('port'), () => {
    console.log('server on port', app.get('port'));
});


//static files
app.use(express.static(path.join(__dirname, 'mostrar')));




//web sockets


const io = SocketIO(server);
  io.on('connection', (socket) => {

    const clientIp = socket.request.connection.remoteAddress;
    connectedClients.push(clientIp);
    socket.emit('clientIpAddress', clientIp);  
   
    if(clientIp == ipprincipal){
        socket.on('datosDesdeCliente', (data) => {
                estudiantes = data.persons;
                
        });
        ;

    }
    else{
        if(connectedClients.includes(ipprincipal)){
            console.log("no es el principal");
            socket.emit('datosDelservidor', { estudiantes });
            
         }
         else{
            console.log("pc principal no conectado")
         }      
    }

    

    

    socket.on('estudiantemodificado', function(data) {
        var estudiante = data.estudiante;

        console.log(estudiante)
        socket.emit('actualizarestudiante', { estudiante });
    })




    // Manejar la desconexión del cliente
    socket.on('disconnect', () => {
        console.log('Cliente desconectado' + connectedClients);
        
        while (connectedClients.indexOf(clientIp) !== -1) {
            let index = connectedClients.indexOf(clientIp);
            connectedClients.splice(index, 1);
        }
        console.log(connectedClients);
    });


});
    






















