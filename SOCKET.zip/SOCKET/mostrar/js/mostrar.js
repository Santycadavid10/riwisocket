var bd // creo variable para guardar base de datos
var elementocaja
var coins = []
var persons = []
var inputBusqueda = document.getElementById('formulario-busqueda');


function iniciarbasededatos() { //creo funcion para cuando inicie base datos // guardo boton en variable
    elementocaja = document.querySelector('.cajaa') // creo addlistener para cuando de click almacenes
    var solicitud = indexedDB.open('DatosEstudiante')
    solicitud.addEventListener('success', Comenzar)     
}

function Comenzar(evento) {
bd = evento.target.result
mostrar()
buscarestudiante();
}


function mostrar() {
    window.scrollTo({
        top: 5,
        behavior: 'smooth'
    });

    transaccion = bd.transaction(['contactos']) // utilizo el metodo transaccion  para indicar que se va hacer una transacion de informacion de  la base de datos  .transacccion(-[almmacen donde se hara la transacion], "readonly " o vacio por que es el valor por defecto )
    almacen = transaccion.objectStore('contactos') // abro almacen
    var index = almacen.index('Buscarriwi');
    var puntero = index.openCursor(null, 'prev'); // abrir cursor
    puntero.addEventListener('success', MostrarContactos)
    function MostrarContactos(evento) {
        var puntero = evento.target.result
            if (puntero) {
                persons.push(puntero.value)
                        const Bontonpersona = document.createElement("button");// creo un elemento boton con ell cual iniciar un proceso
                        const contname = document.createElement("span");  
                        const textocontname = document.createTextNode
                        (puntero.value.nombre + "-----" + "CLan:  " +puntero.value.clan);
                        contname.appendChild(textocontname)
                        contname.classList.add("nombre");
                        const contpuntos = document.createElement("span");  
                        const textocontpuntos = document.createTextNode
                        (puntero.value.riwicoins +  "  " +  " riwicoins");
                        contpuntos.appendChild(textocontpuntos) // string que se desea mostrar
                        contpuntos.classList.add("puntos");
                        Bontonpersona.appendChild(contname);
                        Bontonpersona.appendChild(contpuntos);
                        Bontonpersona.setAttribute("id", puntero.value.id);
                        Bontonpersona.setAttribute("name", puntero.value.nombre);
                        Bontonpersona.setAttribute("clan", puntero.value.clan);
                        Bontonpersona.setAttribute("celular", puntero.value.celular);
                        Bontonpersona.setAttribute("riwicoins", puntero.value.riwicoins);
                        Bontonpersona.addEventListener("click", function (){
                        const nombreBoton = this.getAttribute("name");
                        const clanBoton = this.getAttribute("clan");
                        const idBoton = this.getAttribute("id");
                        const celularBoton = this.getAttribute("celular");
                        const riwiBoton = this.getAttribute("riwicoins");
                        seleccionarestudiante(nombreBoton, clanBoton, idBoton, celularBoton, riwiBoton)
                        
                        });
            
                elementocaja.appendChild(Bontonpersona);
                puntero.continue();
                
                
            }
    }
  // / const socket = io.connect('http://localhost:3001');
   // socket.on('connect', () => {
   // console.log(persons)
    //socket.emit('enviarPersons', persons);
 //});

}
  
function buscarestudiante (){
    inputBusqueda.addEventListener('input', function () {
        var valorBusqueda = inputBusqueda.value;

        while (elementocaja.firstChild) {
            elementocaja.removeChild(elementocaja.firstChild);
        }

        var transaccion = bd.transaction(['contactos']) // utilizo el metodo transaccion  para indicar que se va hacer una transacion de informacion de  la base de datos  .transacccion(-[almmacen donde se hara la transacion], "readonly " o vacio por que es el valor por defecto )
        var almacen = transaccion.objectStore('contactos') // abro almacen
        var puntero = almacen.openCursor() // abrir cursor // creo ad listener que se active al evento suceso
        puntero.addEventListener('success', Mostrarbusquedaresultados) 
        
        function Mostrarbusquedaresultados(evento) {
            var puntero = evento.target.result
            if (puntero) {
                valorBusqueda = valorBusqueda.toString();
                idcomparado = puntero.value.id;
                nombrecomparado = puntero.value.nombre;
                idcomparado = idcomparado.toString();
                if(idcomparado.includes(valorBusqueda) || nombrecomparado.includes(valorBusqueda)){

                    const Bontonpersona = document.createElement("button");// creo un elemento boton con ell cual iniciar un proceso
                    const contname = document.createElement("span");  
                    const textocontname = document.createTextNode
                    (puntero.value.nombre);
                    contname.appendChild(textocontname)
                    contname.classList.add("nombre");
                    const contpuntos = document.createElement("span");  
                    const textocontpuntos = document.createTextNode
                    (puntero.value.riwicoins +  "  " +  " riwicoins");
                    contpuntos.appendChild(textocontpuntos) // string que se desea mostrar
                    contpuntos.classList.add("puntos");
                    Bontonpersona.appendChild(contname);
                    Bontonpersona.appendChild(contpuntos);
                    Bontonpersona.setAttribute("id", puntero.value.id);
                    Bontonpersona.setAttribute("name", puntero.value.nombre);
                    Bontonpersona.setAttribute("clan", puntero.value.clan);
                    Bontonpersona.setAttribute("celular", puntero.value.celular);
                    Bontonpersona.setAttribute("riwicoins", puntero.value.riwicoins);
                    Bontonpersona.addEventListener("click", function (){
                        const nombreBoton = this.getAttribute("name");
                        const clanBoton = this.getAttribute("clan");
                        const idBoton = this.getAttribute("id");
                        const celularBoton = this.getAttribute("celular");
                        const riwiBoton = this.getAttribute("riwicoins");
                        seleccionarestudiante(nombreBoton, clanBoton, idBoton, celularBoton, riwiBoton)
                    });
                    elementocaja.appendChild(Bontonpersona);
                }
                puntero.continue();
            }
        }   
    });
}

function seleccionarestudiante(nombreBoton, clanBoton, idBoton, celularBoton, riwiBoton){
    
    window.scrollTo({
        top: 5,
        behavior: 'smooth'
    });

    while (elementocaja.firstChild) {
        elementocaja.removeChild(elementocaja.firstChild);
    }

    var formularioElement = document.createElement("form");
    var divTitulo = document.createElement("div");
    divTitulo.className = "titulo";
    var h1Element = document.createElement("h1");
    h1Element.textContent = "Editar Estudiante";
    divTitulo.appendChild(h1Element);
    // Agregar el div al formulario
    formularioElement.appendChild(divTitulo);

    // Crear las etiquetas con los inputs y selects
    var etiquetas = [
        { tipo: "number", id: "riwi", placeholder: "Riwi coins =  " + riwiBoton + " poner el +/- y el numero de coins a agregar" },
        { tipo: "text", id: "cliente", placeholder: "Nombre", value: nombreBoton },
        { tipo: "select", id: "clan",  opciones: [ "tesla", "linux", "python", "js"], value: clanBoton},
        { tipo: "number", id: "id", placeholder: "Cedula", value: idBoton },
        { tipo: "number", id: "celular", placeholder: "Celular", value: celularBoton}
    ];

    etiquetas.forEach(function (etiqueta) {
        var labelElement = document.createElement("label");

        if (etiqueta.tipo === "select") {
            var selectElement = document.createElement("select");
            selectElement.id = etiqueta.id;
            etiqueta.opciones.forEach(function (opcion) {
                var optionElement = document.createElement("option");
                optionElement.textContent = opcion;
                selectElement.appendChild(optionElement);
                selectElement.value = etiqueta.value;
            });
        labelElement.appendChild(selectElement);
        } 
        else {
            var inputElement = document.createElement("input");
            inputElement.id = etiqueta.id;
            inputElement.type = etiqueta.tipo;
            inputElement.placeholder = etiqueta.placeholder;
            inputElement.value = etiqueta.value;
            labelElement.appendChild(inputElement);
        }
        formularioElement.appendChild(labelElement);
    });

// Crear el botón
    var botonEditar = document.createElement("button");
    botonEditar.className = "red";
    botonEditar.type = "button";
    botonEditar.id = "editar";
    botonEditar.textContent = "Editar";
    botonEditar.addEventListener("click", function (){

        var N = document.querySelector('#cliente').value
        var I = document.querySelector('#id').value
        var C = document.querySelector('#clan').value
        var CE = document.querySelector('#celular').value
        var  tartaria = document.querySelector('#riwi').value;
        if(tartaria == ""){
            tartaria = 0;
        }
        var R =  parseInt(tartaria, 10) + parseInt(riwiBoton, 10);

        var transaccion = bd.transaction(['contactos'], 'readwrite')
        var almacen = transaccion.objectStore('contactos')
        
        var estudiante = {
            nombre: N,
            id: I,
            clan: C,
            celular: CE,
            riwicoins: R,
        }

        almacen.put(estudiante);
        while (elementocaja.firstChild) {
            elementocaja.removeChild(elementocaja.firstChild);  
        }
        const socket = io.connect('http://localhost:3001');
        socket.emit('enviarDatos', estudiante);
        mostrar();


    });




    

    var botonEliminar = document.createElement("button");
    botonEliminar.className = "red";
    botonEliminar.type = "button";
    botonEliminar.id = "eliminar";
    botonEliminar.textContent = "Eliminar";
    botonEliminar.addEventListener("click", function (){
        console.log("santy");
    });
    // Agregar el botón al formulario
    formularioElement.appendChild(botonEditar);
    formularioElement.appendChild(botonEliminar);
    // Agregar el formulario al contenedor con la clase "cajaa"
    elementocaja.appendChild(formularioElement);


}




 
window.addEventListener('load', iniciarbasededatos)

const socket = io.connect('http://localhost:3001');

socket.on('enviarPersons', (persons) => {
    console.log('Array de personas recibido en el cliente:', persons);
    var transaccion = bd.transaction(['contactos'], 'readwrite')
    var almacen = transaccion.objectStore('contactos')
    console.log(almacen)
    almacen.put(persons);
    while (elementocaja.firstChild) {
        elementocaja.removeChild(elementocaja.firstChild);  
    }
    mostrar()
});