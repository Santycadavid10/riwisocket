const path = require('path');
const express = require('express');
const app = express();
const SocketIO = require('socket.io')
const os = require('os');
const connectedClients = [];
app.set('port', process.env.PORT || 3002)

const interfaces = os.networkInterfaces();
const IPconectada = interfaces.enp1s0[0].address;
console.log(IPconectada)
//static files
app.use(express.static(path.join(__dirname, 'mostrar')));

const server = app.listen(app.get('port'), () => {
    console.log('server on port', app.get('port'));
});


//web sockets


const io = SocketIO(server);
  io.on('connection', (socket) => {
    const clientIp = socket.request.connection.remoteAddress;
    console.log("cliente conecta ip: " + clientIp)
    connectedClients.push(clientIp);
    socket.emit('clientIpAddress', clientIp);  


    

    // Manejar la desconexión del cliente
    socket.on('disconnect', () => {
        console.log('Cliente desconectado');
        connectedClients = connectedClients.filter(animal => animal != clientIp);
        console.log('Cliente desconectado' + connectedClients);
    });



    console.log("conectados " + connectedClients)


});




